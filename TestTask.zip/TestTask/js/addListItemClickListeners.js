        // Получаем все элементы списка
        const listItems = document.querySelectorAll('.info-container__list-name-li');

        // Добавляем обработчик клика для каждого элемента
        listItems.forEach(item => {
            item.addEventListener('click', function () {
                // Удаляем класс active у всех элементов списка
                listItems.forEach(el => el.classList.remove('active'));

                // Добавляем класс active к текущему элементу
                this.classList.add('active');
            });
        });
